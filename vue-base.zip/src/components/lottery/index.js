import GamePool from "./GamePool";
import GameBonus from "./GameBonus";
import GameBet from "./GameBet";
import GameLog from "./GameLog";

export default {
    GameBet, GameBonus, GameLog, GamePool
}
