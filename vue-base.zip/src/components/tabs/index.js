import TabBets from './TabBets';
import TabTop from './TabTop';

export default {
    TabBets,
    TabTop
}
