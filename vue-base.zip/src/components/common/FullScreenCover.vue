<template>

</template>

<script>
    export default {
        name: "FullScreenCover"
    }
</script>

<style scoped>

</style>
