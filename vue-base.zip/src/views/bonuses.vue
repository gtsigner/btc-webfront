<template>
    <h1>bonuses</h1>
</template>

<script>
    export default {
        name: "bonuses"
    }
</script>

<style scoped>

</style>
