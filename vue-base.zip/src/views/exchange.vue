<template>
    <h1>exchange</h1>
</template>

<script>
    export default {
        name: "exchange"
    }
</script>

<style scoped>

</style>
