<template>
    <div class="login-view">
    </div>
</template>

<script>

    export default {
        name: 'Login',

    };
</script>

