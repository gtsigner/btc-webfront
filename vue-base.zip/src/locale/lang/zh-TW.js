export default {
    home: '首頁',

}
