export const SET_USER = 'SET_USER';
export const SET_LOGIN = 'SET_LOGIN';
export const SET_GAME = 'SET_GAME';
export const SET_ACCESS_TOKEN = 'SET_ACCESS_TOKEN';

export const SET_LANG = 'SET_LANG';
