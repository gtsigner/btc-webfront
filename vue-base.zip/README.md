## 安装环境

node 8.x npm 或者yarn



## 执行


```
yarn

yarn serve

yarm build

```

