vue页面  https://betdice.one/lottery   https://betdice.one/ 实现所有页面设计和特效 后段数据调用（不用实现后端）要求 HTML CSS JavaScript 代码清晰 可维护

实现多语言：中文和英文   多语言是一键可以切换的 网页可以通过添加语言文件，添加更多语言。
红利功能除外


# developers contact

maintainer: godtoy@oeynet.com 1716771371@qq.com zhaojunlike@gmail.com
-----

phone: 17311301741
-----

wechat: zhaojunlike
-----

權利：成都易猿云，成都易猿网络
-----
